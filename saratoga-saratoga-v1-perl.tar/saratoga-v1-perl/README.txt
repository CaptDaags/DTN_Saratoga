Saratoga Transfer Protocol Version 1
David Stewart

This is the README for the Saratoga perl script. This script implements
version 1 of the Saratoga protocol, as described in the internet-draft:
http://tools.ietf.org/html/draft-wood-tsvwg-saratoga

The Saratoga protocol is described in more detail at:
http://saratoga.sourceforge.net/


HISTORY

The original Saratoga protocol, version 0, was developed by Surrey
Satellite Technology Ltd (SSTL) for downloading remote-sensing imagery
from its Disaster Monitoring Constellation (DMC) satellites over highly 
asymmetric private links. There is no need for congestion control 
in such deployments.

In 2007, NASA Glenn Research Center (GRC) wrote a script to support
successful testing of Delay/Disruption Tolerant Networks (DTN) over
multiple ground stations, using SSTL's UK-DMC satellite. At that time
the script was used only as a Saratoga client. Although the code for
the server function was written, the server was not used in the 2007
testing.

The server function of the original code has now been debugged for basic
operations, with plans to fully implement version 1 in the near future.

Please consider this as beta code, where not all features function.


NOTE: PERFORMANCE LIMITATIONS

This perl implementation of Saratoga version 1 was written specifically for 
interoperability testing to validate the specification as described in
the internet-draft. Being in perl rather than C, this implementation was
not written with performance in mind. This implementation should not be
used to assess the speed or performance of the Saratoga protocol.

This implementation copies the entire file contents to RAM prior to
transmission, and so very large files require very large amounts of RAM.
Also, the implementation performs serial file transfers, meaning that one
complete file is transferred prior to a second file starting.

Other implementations maintain multiple queues and send files multiplexed
via round-robin, thereby eliminating head-of-line blocking. This is not
considered a significant issue, as this perl implementation is intended
for protocol interoperability testing, not for performance.


NOTE: LAYER-2 RATE ADJUSTMENT TRIGGERS

This perl implementation has also been used to test some layer-2 
trigger concepts. It can respond to modem link property 
advertisements to autonomously adjust its transmission rate.

Further details on modem link property advertisements, with
modemlpa packet generation code, are at:
http://modemlpa.sourceforge.net/

SCRIPT REQUIREMENTS

Perl language.

The following Perl modules are required:
    Data::Dumper;
    POSIX;
    Socket;
    IO::Socket::INET;
    IO::Interface::Multicast;
    Sys::Hostname;
    Time::HiRes;
    Digest::MD5::File;

Not all of these modules are included in every operating system.
Modules may need to be installed via the Comprehensive Perl
Archive Network (CPAN):
http://www.cpan.org/
with e.g.
cpan Digest::MD5::File


HOW TO USE THIS SCRIPT

The saratoga_v1.pl script is an implementation of the Saratoga 
Transfer Protocol Version 1.  It is a file transfer protocol that 
uses UDP and negative acknowledgements for efficient file transfers 
over dedicated, single-hop, single-use, asymmetric satellite links.
The script can also be used across networks consisting of multiple hops,
but that is probably not the best scenario for this application.

The script implements both server (data send) and client (data receive)
algorithms, so the same script runs on both the client and server host
machines.

There is a configuration file ('sara.conf') that resides in the same
directory as the script. You will need to edit this file before using
the script. Use this sara.conf file to set the host and peer IP addresses,
the data rate and to turn on debug mode. Note that debug mode is very
chatty and expects a reader who is familiar with the script's workings.

The sara.conf configuration file is read in once at start up.  The 
configuration can be altered in the command line interpreter provided
by the script, but will revert back to the sara.conf defaults when the
script is restarted.  If 'sara.conf' is altered the script will have to
be restarted for the changes to take effect.  


SARATOGA FEATURES NOT YET IMPLEMENTED IN THIS SCRIPT
Support for C-implementation speed or performance.
Support for IPv6 or UDP-Lite
Support for extremely large files (128-bit descriptors)


SUPPORTED COMMANDS:

bye					- Exits program.
close					- Closes current connection to server.
					  NOT TESTED!
delete					- Deletes file in remote directory. 
dir	<path>  			- List contents of remote directory.
					  default is './'
disconnect				- Same as 'close'.
exit					- Same as 'bye'.
get	<path/filename>			- Downloads file from remote host.
help					- Not yet implemented.
lcd	<path>				- Change local directory.
					  NOT TESTED!
ls	<path>				- Same as 'dir'.
open <server_address>			- Open connection to saratoga server.
pwd 					- Present working directory.
					  Not implemented.
quit					- Same as 'bye'.
rate <kbps>				- Sets packet transmission rate
					  on local host. i.e. 2000 = 2 Mbps
recv 					- Same as get.
verbose 				- Turns on/off debugging information
					  that is written to screen or to a
					  syslog file.

The path for 'ls' and 'get' should default to ./ (directory that the 
script is running on the remote host).  Likewise, the 'get' command 
will write the file to the directory that the script is running in. 

The 'get' command is issued from the receiving machine to serving machine.
You should see GET_REQEST packets flow between sender and receiver.

The 'put' command is issued on the serving machine.  In this perl
implementation, no PUT_REQUEST packets are sent between sender and receiver.
Rather, the sender sends metatdata and data and the receiver accepts the data.
This is the same as a blind 'put' as described in the internet draft.


CONFIGURATION FILE:

'sara.conf'

# host address of this machine Saratoga is running on
$C_hostaddr = "192.55.90.133";
# host address of the peer machine
$C_peeraddr = "192.55.90.214";
$C_verbose  = 0; # set to 1 to turn debugging on
$C_rate = 2000;  # server's transmission data rate in kbps. 0 = line rate.
$C_eid = "Space-Asset"; #endpoint id used in beacon
$C_multicast_interface	= 'eth2'; #specifies which interface send beacons
# the following specifies which interface receives modemlpa layer-2 triggers
my $C_lpa_multicast_intf = 'eth2';

The configuration file above allows you to set the host & peer addresses,
debug mode and data rate.  This file is read in and executed as part of the
script. Comments require the '#' character at start.


QUESTIONS:

email: dstewart@grc.nasa.gov


HISTORY:

Script begun by Dave Stewart, 14 May 2010.
